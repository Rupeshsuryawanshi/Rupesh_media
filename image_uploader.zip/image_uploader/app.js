const express = require('express');
const multer = require('multer');
const ejs = require('ejs');
const path = require('path');
const fs = require('fs')
const app = express()
var JSAlert = require("js-alert");
let images = []
const directoryPath = path.join(__dirname, '/public/uploads');

var data;
function img(req, res){
  images = []
  fs.readdir(directoryPath, function (err, files) {
  //handling error
  if (err) {
      return console.log('Unable to scan directory: ' + err);
  } 
  //listing all files using forEach
  
  files.forEach(function (file) {
    console.log(file)
     data=file.length;
    images.push(`uploads/${file}`)
  });
  
  console.log("imaes....22............", images); 
  if(res){
  res.render('index', {
    msg: 'File Uploaded!',
    images
  });
}

});
}//take image

img("", "")
console.log(directoryPath)
// Set The Storage Engine
const storage = multer.diskStorage({
  destination: './public/uploads/',
  filename: function(req, file, cb){
    cb(null,file.fieldname + '-' + Date.now() + path.extname(file.originalname));
  }
});//image storage



// Init Upload
const upload = multer({
  storage: storage,
  limits:{fileSize: 1000000},
  fileFilter: function(req, file, cb){
    checkFileType(file, cb);
  }
}).single('myImage');

// Check File Type
function checkFileType(file, cb){
  // Allowed ext
  const filetypes = /jpeg|jpg|png|gif/;
  // Check ext
  const extname = filetypes.test(path.extname(file.originalname).toLowerCase());
  // Check mime
  const mimetype = filetypes.test(file.mimetype);

  if(mimetype && extname){
    return cb(null,true);
  } else {
    cb('Error: Images Only!');
  }
}


// EJS
app.set('view engine', 'ejs');

// Public Folder
app.use(express.static('./public'));

app.get('/', (req, res) => {
  
  img(req, res)
});//home page
//photo uplode
app.post('/upload', (req, res) => {
  
  upload(req, res, (err) => {
    if(err){
      
      res.render('index', {
        
        msg: err

      });
    } else {
      //no file is selected check
      if(req.file == undefined){

        console.log(data);
        res.render("index",{
          msg:"please uplode file",
          data:data,
          images

        })
      }//file check
      //atlist one file check
        else{
          img(req, res)
      }
     } //file check
    
  });
});//photo uplode

const port = 3000;

app.listen(port, () => console.log(`Server started on port ${port}`));